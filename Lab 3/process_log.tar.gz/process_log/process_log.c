#include <unistd.h>
#include <stdlib.h>
#include "process_log.h"

// Library Functions
int get_proc_log_level() {
    int get = syscall(PROC_GET_CALL);
    return get;
}

int set_proc_log_level(int new_level) {
    int set = syscall(PROC_SET_CALL, new_level);
    return set;
}

int proc_log_message(int level, char *message) {
    int log = syscall(PROC_LOG_CALL, message, level);
    return log;
}

// Harness Funtions
int* retrieve_set_level_params(int new_level) {
    int *params = malloc(sizeof(int) * 3);
    params[0] = 436;
    params[1] = 1;
    params[2] = new_level;
    return params;
}

int* retrieve_get_level_params() {
    int *params = malloc(sizeof(int) * 2);
    params[0] = 435;
    params[1] = 0;
    return params;
}

int interpret_set_level_result(int ret_value) {
    return ret_value;
}

int interpret_get_level_result(int ret_value) {
    return ret_value;
}

int interpret_log_message_result(int ret_value) {
    return ret_value;
}